export interface VehicleData {
    id: number,
    odometro: number,
    nivelCombustivel: number,
    status: string,
    lat: number,
    long: number 
}